HOW TO RUN THE PROJECT

1. Install Node.js
Download:
https://nodejs.org

2. Install MongoDB Community Server
Download:
https://www.mongodb.com/try/download/community

3. Start MongoDB
Open services or terminal and start MongoDB.

4. Open Project Folder in VS Code

5. Run Backend
Open terminal:

cd backend
npm install
npm run dev

You should see:
MongoDB Connected
Server running on port 5000

6. Run Frontend
Open another terminal:

cd frontend
npm install
npm start

7. Open Browser
http://localhost:3000

8. Add Movies in MongoDB Compass

Database:
movieReviewDB

Collection:
movies

Sample Data:

{
"title":"Interstellar",
"image":"https://images.unsplash.com/photo-1489599849927-2ee91cede3ba",
"description":"Science fiction movie"
}

{
"title":"Avengers Endgame",
"image":"https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c",
"description":"Marvel superhero movie"
}
