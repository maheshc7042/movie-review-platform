const express = require("express");
const router = express.Router();
const Review = require("../models/Review");

router.get("/:movieId", async (req, res) => {
  const reviews = await Review.find({ movieId: req.params.movieId });
  res.json(reviews);
});

router.post("/", async (req, res) => {
  const review = new Review(req.body);
  const savedReview = await review.save();
  res.json(savedReview);
});

module.exports = router;