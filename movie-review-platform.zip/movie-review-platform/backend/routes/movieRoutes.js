const express = require("express");
const router = express.Router();
const Movie = require("../models/Movie");

router.get("/", async (req, res) => {
  const movies = await Movie.find();
  res.json(movies);
});

router.post("/", async (req, res) => {
  const movie = new Movie(req.body);
  const savedMovie = await movie.save();
  res.json(savedMovie);
});

module.exports = router;