const mongoose = require("mongoose");

const reviewSchema = new mongoose.Schema({
  movieId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Movie",
  },
  username: String,
  rating: Number,
  comment: String,
});

module.exports = mongoose.model("Review", reviewSchema);