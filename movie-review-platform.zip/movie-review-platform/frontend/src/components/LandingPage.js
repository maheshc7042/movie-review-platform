function LandingPage() {
  return (
    <div className="landing">
      <h1>Welcome to Movie Review Platform</h1>
      <p>Review and Rate Your Favorite Movies</p>
    </div>
  );
}

export default LandingPage;