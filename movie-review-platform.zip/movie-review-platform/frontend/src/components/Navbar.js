function Navbar() {
  return (
    <nav className="navbar">
      <h1>MERN Movie Review Platform</h1>
    </nav>
  );
}

export default Navbar;