import { useEffect, useState } from "react";
import axios from "axios";
import MovieCard from "./MovieCard";

function MovieList() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    const { data } = await axios.get("http://localhost:5000/api/movies");
    setMovies(data);
  };

  return (
    <div className="movie-container">
      {movies.map((movie) => (
        <MovieCard key={movie._id} movie={movie} />
      ))}
    </div>
  );
}

export default MovieList;