import { useEffect, useState } from "react";
import axios from "axios";
import ReviewForm from "./ReviewForm";

function MovieCard({ movie }) {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    const { data } = await axios.get(
      `http://localhost:5000/api/reviews/${movie._id}`
    );
    setReviews(data);
  };

  return (
    <div className="movie-card">
      <img src={movie.image} alt={movie.title} />
      <h2>{movie.title}</h2>
      <p>{movie.description}</p>

      <h3>Reviews</h3>

      {reviews.map((review) => (
        <div key={review._id} className="review-box">
          <strong>{review.username}</strong>
          <p>Rating: {review.rating}/5</p>
          <p>{review.comment}</p>
        </div>
      ))}

      <ReviewForm movieId={movie._id} refreshReviews={fetchReviews} />
    </div>
  );
}

export default MovieCard;