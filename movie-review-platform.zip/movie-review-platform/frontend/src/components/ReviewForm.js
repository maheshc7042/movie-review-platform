import { useState } from "react";
import axios from "axios";

function ReviewForm({ movieId, refreshReviews }) {
  const [username, setUsername] = useState("");
  const [rating, setRating] = useState("");
  const [comment, setComment] = useState("");

  const submitReview = async (e) => {
    e.preventDefault();

    await axios.post("http://localhost:5000/api/reviews", {
      movieId,
      username,
      rating,
      comment,
    });

    setUsername("");
    setRating("");
    setComment("");

    refreshReviews();
  };

  return (
    <form onSubmit={submitReview} className="review-form">
      <input
        type="text"
        placeholder="Your Name"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />

      <input
        type="number"
        placeholder="Rating"
        min="1"
        max="5"
        value={rating}
        onChange={(e) => setRating(e.target.value)}
        required
      />

      <textarea
        placeholder="Write Review"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        required
      />

      <button type="submit">Submit Review</button>
    </form>
  );
}

export default ReviewForm;