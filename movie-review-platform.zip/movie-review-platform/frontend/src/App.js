import Navbar from "./components/Navbar";
import LandingPage from "./components/LandingPage";
import MovieList from "./components/MovieList";
import "./App.css";

function App() {
  return (
    <div>
      <Navbar />
      <LandingPage />
      <MovieList />
    </div>
  );
}

export default App;